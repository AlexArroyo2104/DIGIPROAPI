//
//  DIGIPROSDKATO.h
//  DIGIPROSDKATO
//
//  Created by Jonathan Viloria M on 5/6/19.
//  Copyright © 2019 Jonathan Viloria M. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DIGIPROSDKATO.
FOUNDATION_EXPORT double DIGIPROSDKATOVersionNumber;

//! Project version string for DIGIPROSDKATO.
FOUNDATION_EXPORT const unsigned char DIGIPROSDKATOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DIGIPROSDKATO/PublicHeader.h>



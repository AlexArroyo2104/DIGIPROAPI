//
//  MyBottomView.h
//  MegLiveDemo
//
//  Created by megvii on 16/6/8.
//  Copyright © megvii. All rights reserved.
//

#import <MGLivenessDetection/MGLivenessDetection.h>

@interface MyBottomView : MGBaseBottomManager

@end

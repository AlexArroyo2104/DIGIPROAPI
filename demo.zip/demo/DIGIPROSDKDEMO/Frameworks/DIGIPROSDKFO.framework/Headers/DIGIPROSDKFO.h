//
//  DIGIPROSDKFO.h
//  DIGIPROSDKFO
//
//  Created by Jonathan Viloria M on 5/7/19.
//  Copyright © 2019 Jonathan Viloria M. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DIGIPROSDKFO.
FOUNDATION_EXPORT double DIGIPROSDKFOVersionNumber;

//! Project version string for DIGIPROSDKFO.
FOUNDATION_EXPORT const unsigned char DIGIPROSDKFOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DIGIPROSDKFO/PublicHeader.h>


#import "DIGIPROSDKFO/Headfiles.h"

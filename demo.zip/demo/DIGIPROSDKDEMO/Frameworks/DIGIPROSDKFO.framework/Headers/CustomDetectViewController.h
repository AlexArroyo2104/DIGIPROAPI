//
//  CustomDetectViewController.h
//  MegLiveDemo
//
//  Created by megviio on 2017/5/26.
//  Copyright © megvii. All rights reserved.
//

#import <MGLivenessDetection/MGLiveDetectViewController.h>

@interface CustomDetectViewController : MGLiveDetectViewController

@end

//
//  DIGIPROSDKUI.h
//  DIGIPROSDKUI
//
//  Created by Jonathan Viloria M on 5/2/19.
//  Copyright © 2019 Jonathan Viloria M. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DIGIPROSDKUI.
FOUNDATION_EXPORT double DIGIPROSDKUIVersionNumber;

//! Project version string for DIGIPROSDKUI.
FOUNDATION_EXPORT const unsigned char DIGIPROSDKUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DIGIPROSDKUI/PublicHeader.h>



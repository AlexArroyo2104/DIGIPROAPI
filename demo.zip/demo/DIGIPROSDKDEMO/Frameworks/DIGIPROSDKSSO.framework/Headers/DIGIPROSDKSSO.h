//
//  DIGIPROSDKSSO.h
//  DIGIPROSDKSSO
//
//  Created by Jonathan Viloria M on 5/2/19.
//  Copyright © 2019 Jonathan Viloria M. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DIGIPROSDKSSO.
FOUNDATION_EXPORT double DIGIPROSDKSSOVersionNumber;

//! Project version string for DIGIPROSDKSSO.
FOUNDATION_EXPORT const unsigned char DIGIPROSDKSSOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DIGIPROSDKSSO/PublicHeader.h>


//#import <DIGIPROSDKSSO/Firebase.h>

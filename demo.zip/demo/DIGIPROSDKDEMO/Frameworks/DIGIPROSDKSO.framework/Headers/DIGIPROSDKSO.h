//
//  DIGIPROSDKSO.h
//  DIGIPROSDKSO
//
//  Created by Jonathan Viloria M on 5/2/19.
//  Copyright © 2019 Jonathan Viloria M. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DIGIPROSDKSO.
FOUNDATION_EXPORT double DIGIPROSDKSOVersionNumber;

//! Project version string for DIGIPROSDKSO.
FOUNDATION_EXPORT const unsigned char DIGIPROSDKSOVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DIGIPROSDKSO/PublicHeader.h>


